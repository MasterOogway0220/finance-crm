var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/brokerage/daily/route.js")
R.c("server/chunks/[root-of-the-server]__8696eb20._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/_next-internal_server_app_api_brokerage_daily_route_actions_5e0541a8.js")
R.m(33117)
module.exports=R.m(33117).exports
