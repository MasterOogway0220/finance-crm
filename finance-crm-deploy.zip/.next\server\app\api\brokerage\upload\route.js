var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/brokerage/upload/route.js")
R.c("server/chunks/[root-of-the-server]__34c3c0cd._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_xlsx_xlsx_mjs_539ebb60._.js")
R.c("server/chunks/_next-internal_server_app_api_brokerage_upload_route_actions_1f421168.js")
R.m(82663)
module.exports=R.m(82663).exports
