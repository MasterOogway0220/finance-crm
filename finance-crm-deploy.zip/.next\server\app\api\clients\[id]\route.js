var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/clients/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__00dc9d98._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/_next-internal_server_app_api_clients_[id]_route_actions_3b263a6d.js")
R.m(98814)
module.exports=R.m(98814).exports
