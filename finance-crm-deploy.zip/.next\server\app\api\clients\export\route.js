var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/clients/export/route.js")
R.c("server/chunks/[root-of-the-server]__2acee56e._.js")
R.c("server/chunks/[root-of-the-server]__ef96b813._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/_next-internal_server_app_api_clients_export_route_actions_b74202ca.js")
R.m(51640)
module.exports=R.m(51640).exports
