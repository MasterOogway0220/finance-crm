var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/clients/import/route.js")
R.c("server/chunks/[root-of-the-server]__e14b9e6c._.js")
R.c("server/chunks/[root-of-the-server]__ef96b813._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/_next-internal_server_app_api_clients_import_route_actions_1af79dda.js")
R.m(38082)
module.exports=R.m(38082).exports
