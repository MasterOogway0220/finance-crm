var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/clients/route.js")
R.c("server/chunks/[root-of-the-server]__4d6f14f3._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/_next-internal_server_app_api_clients_route_actions_cf8c8248.js")
R.m(56913)
module.exports=R.m(56913).exports
