var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cron/monthly-reset/route.js")
R.c("server/chunks/[root-of-the-server]__bf77bbc5._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_cron_monthly-reset_route_actions_3e20db80.js")
R.m(36213)
module.exports=R.m(36213).exports
