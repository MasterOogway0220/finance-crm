var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cron/task-expiry/route.js")
R.c("server/chunks/[root-of-the-server]__56f8b4bf._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_cron_task-expiry_route_actions_849c3aa6.js")
R.m(24211)
module.exports=R.m(24211).exports
