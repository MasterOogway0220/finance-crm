var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dashboard/admin/route.js")
R.c("server/chunks/[root-of-the-server]__e16d7be0._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/_next-internal_server_app_api_dashboard_admin_route_actions_54e273e0.js")
R.m(90314)
module.exports=R.m(90314).exports
