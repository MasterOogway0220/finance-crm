var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dashboard/equity/route.js")
R.c("server/chunks/[root-of-the-server]__e655f1d4._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/_next-internal_server_app_api_dashboard_equity_route_actions_3f3680cf.js")
R.m(43892)
module.exports=R.m(43892).exports
