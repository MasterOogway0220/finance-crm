var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dashboard/mf/route.js")
R.c("server/chunks/[root-of-the-server]__b361e0f0._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/_next-internal_server_app_api_dashboard_mf_route_actions_cc3bf46d.js")
R.m(74587)
module.exports=R.m(74587).exports
