var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/employees/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__e31e5637._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_employees_[id]_route_actions_3e4e8a8f.js")
R.m(26190)
module.exports=R.m(26190).exports
