var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/[id]/read/route.js")
R.c("server/chunks/[root-of-the-server]__99095ddf._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/_next-internal_server_app_api_notifications_[id]_read_route_actions_d399f413.js")
R.m(43493)
module.exports=R.m(43493).exports
