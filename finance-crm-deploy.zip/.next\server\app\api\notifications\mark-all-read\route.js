var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/mark-all-read/route.js")
R.c("server/chunks/[root-of-the-server]__fab39888._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/_next-internal_server_app_api_notifications_mark-all-read_route_actions_dcdce132.js")
R.m(62616)
module.exports=R.m(62616).exports
