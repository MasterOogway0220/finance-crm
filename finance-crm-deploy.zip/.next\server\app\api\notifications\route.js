var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/route.js")
R.c("server/chunks/[root-of-the-server]__d4066bf4._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/_next-internal_server_app_api_notifications_route_actions_850cb780.js")
R.m(94483)
module.exports=R.m(94483).exports
