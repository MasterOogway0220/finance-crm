var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/reports/brokerage/route.js")
R.c("server/chunks/[root-of-the-server]__06e8eb01._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/_next-internal_server_app_api_reports_brokerage_route_actions_2f7af130.js")
R.m(78334)
module.exports=R.m(78334).exports
