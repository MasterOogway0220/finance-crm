var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/reports/export/route.js")
R.c("server/chunks/[root-of-the-server]__b2245907._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_xlsx_xlsx_mjs_539ebb60._.js")
R.c("server/chunks/_next-internal_server_app_api_reports_export_route_actions_1712ed18.js")
R.m(36214)
module.exports=R.m(36214).exports
