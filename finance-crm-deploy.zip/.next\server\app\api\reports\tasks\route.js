var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/reports/tasks/route.js")
R.c("server/chunks/[root-of-the-server]__0742931d._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/_next-internal_server_app_api_reports_tasks_route_actions_d1c2c271.js")
R.m(33850)
module.exports=R.m(33850).exports
