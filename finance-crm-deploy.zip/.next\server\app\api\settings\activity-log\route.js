var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/settings/activity-log/route.js")
R.c("server/chunks/[root-of-the-server]__34d2bef5._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/_next-internal_server_app_api_settings_activity-log_route_actions_1bf06a14.js")
R.m(60585)
module.exports=R.m(60585).exports
