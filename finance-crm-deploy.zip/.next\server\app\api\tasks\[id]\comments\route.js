var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/tasks/[id]/comments/route.js")
R.c("server/chunks/[root-of-the-server]__d74b2601._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/_next-internal_server_app_api_tasks_[id]_comments_route_actions_71745d03.js")
R.m(14474)
module.exports=R.m(14474).exports
