var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/tasks/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__cc39ff9c._.js")
R.c("server/chunks/_4f846f1e._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/_next-internal_server_app_api_tasks_[id]_route_actions_8de83605.js")
R.m(60812)
module.exports=R.m(60812).exports
