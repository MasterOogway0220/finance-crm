module.exports=[7318,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_brokerage_route_actions_a39f3903.js.map