module.exports=[69019,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_clients_%5Bid%5D_route_actions_3b263a6d.js.map