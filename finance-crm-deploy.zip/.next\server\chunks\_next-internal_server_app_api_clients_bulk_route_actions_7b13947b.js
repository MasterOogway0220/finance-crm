module.exports=[16156,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_clients_bulk_route_actions_7b13947b.js.map