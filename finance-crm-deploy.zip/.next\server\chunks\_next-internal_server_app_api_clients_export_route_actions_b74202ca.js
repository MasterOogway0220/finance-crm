module.exports=[35115,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_clients_export_route_actions_b74202ca.js.map