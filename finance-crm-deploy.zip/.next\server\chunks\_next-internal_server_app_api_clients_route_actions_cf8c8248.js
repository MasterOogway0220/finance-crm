module.exports=[50074,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_clients_route_actions_cf8c8248.js.map