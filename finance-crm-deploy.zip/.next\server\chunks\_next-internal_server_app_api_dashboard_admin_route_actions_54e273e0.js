module.exports=[93242,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dashboard_admin_route_actions_54e273e0.js.map