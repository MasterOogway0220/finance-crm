module.exports=[97585,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dashboard_backoffice_route_actions_ef678592.js.map