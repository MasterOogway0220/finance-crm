module.exports=[8272,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dashboard_equity_route_actions_3f3680cf.js.map