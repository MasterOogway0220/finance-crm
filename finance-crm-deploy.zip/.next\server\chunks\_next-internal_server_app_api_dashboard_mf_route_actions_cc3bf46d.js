module.exports=[97821,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dashboard_mf_route_actions_cc3bf46d.js.map