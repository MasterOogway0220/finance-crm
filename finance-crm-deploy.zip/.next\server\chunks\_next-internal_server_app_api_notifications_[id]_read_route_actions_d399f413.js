module.exports=[49437,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_notifications_%5Bid%5D_read_route_actions_d399f413.js.map