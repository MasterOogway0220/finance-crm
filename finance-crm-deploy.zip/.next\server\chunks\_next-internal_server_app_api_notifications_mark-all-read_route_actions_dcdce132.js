module.exports=[75028,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_notifications_mark-all-read_route_actions_dcdce132.js.map