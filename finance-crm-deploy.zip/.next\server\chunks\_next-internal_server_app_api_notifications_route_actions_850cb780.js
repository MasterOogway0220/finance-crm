module.exports=[14007,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_notifications_route_actions_850cb780.js.map