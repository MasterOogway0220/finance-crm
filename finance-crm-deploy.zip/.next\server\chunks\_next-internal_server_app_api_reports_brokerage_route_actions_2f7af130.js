module.exports=[15652,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_reports_brokerage_route_actions_2f7af130.js.map