globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/62b8e3559016940f.js",
    "static/chunks/40f1846f7d007f42.js",
    "static/chunks/fcf588a7302715c4.js",
    "static/chunks/aee6c7720838f8a2.js",
    "static/chunks/turbopack-971fa04aa240e71f.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];