var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__758af4a2._.js")
R.c("server/chunks/[root-of-the-server]__75a5a7d5._.js")
R.m(89997)
module.exports=R.m(89997).exports
